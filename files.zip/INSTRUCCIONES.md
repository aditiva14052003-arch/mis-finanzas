# 📱 Guía: Instalar tu App de Finanzas en iOS

## ¿Qué acabas de recibir?

Creé una **Progressive Web App (PWA)** que funciona como una app nativa en tu teléfono. Es como tener una aplicación descargada desde la App Store, pero sin necesidad de descargarla. Todo se guarda en tu teléfono y funciona sin internet.

### Archivos que tienes:
- `financial-app.html` → La app completa (la interfaz)
- `manifest.json` → Configuración para que iOS la reconozca como app
- `sw.js` → El "poder offline" - permite usar la app sin internet
- Esta guía que estás leyendo

---

## PASO 1️⃣: Subir los archivos a un servidor

Para que iOS pueda instalar la app, los archivos necesitan estar en un servidor web. Tienes 3 opciones:

### Opción A: Usar Netlify (RECOMENDADO - Es gratis y fácil)

1. Ve a **https://netlify.com**
2. Crea una cuenta con tu email
3. En el panel de Netlify, arrastra y suelta los 3 archivos (`financial-app.html`, `manifest.json`, `sw.js`)
4. Netlify te dará un link como: `https://tu-nombre.netlify.app`
5. Tu app estará lista en ese link ✓

### Opción B: Usar Vercel (También gratis)

1. Ve a **https://vercel.com**
2. Sube una carpeta con los 3 archivos
3. Vercel te dará un link instantáneamente

### Opción C: Tu propio servidor

Si tienes hosting propio (GoDaddy, Bluehost, etc.), sube los 3 archivos a la raíz de tu dominio.

**Importante:** Después de subir, espera 30 segundos antes de continuar.

---

## PASO 2️⃣: Instalar en iOS (iPhone)

Ahora que la app está en línea, instálala en tu teléfono:

### En Safari (el navegador de Apple):

1. **Abre Safari** en tu iPhone
2. **Ve a tu link** (ej: https://tu-nombre.netlify.app/financial-app.html)
3. Espera a que cargue completamente
4. Toca el **botón de compartir** (el cuadrado con flecha hacia arriba) abajo a la derecha
5. Desplázate hacia la derecha en el menú que aparece
6. Toca **"Añadir a la pantalla de inicio"** (Add to Home Screen)
7. Dale un nombre (ej: "Mis Finanzas")
8. Toca **"Añadir"** (Add)

**¡Listo!** La app aparecerá en tu pantalla principal como un ícono 💰

---

## PASO 3️⃣: Usar la app

### Dashboard (Pestaña 1 - Inicio)
- **Ve tu resumen** de ingresos y gastos totales arriba
- **Resumen por categoría**: ves cuánto gastas en cada categoría
- Ideal para entender a dónde va tu dinero

### + Agregar (Pestaña 2)
**Para registrar cualquier transacción:**
1. Elige si es "Gasto" o "Ingreso"
2. Selecciona la categoría (Alimentación, Transporte, etc.)
3. Escribe una descripción (ej: "Almuerzo en restaurante")
4. Ingresa el monto
5. Confirma la fecha
6. Toca "Guardar Transacción"

**Categorías incluidas:**
- Alimentación
- Transporte
- Entretenimiento
- Servicios
- Salud
- Trabajo
- Otros

### Historial (Pestaña 3)
- **Todas tus transacciones** ordenadas por fecha (más recientes arriba)
- **Ves el monto, descripción, categoría y fecha** de cada transacción
- **Para eliminar una**: toca el botón ✕ rojo
- Las transacciones de **ingreso salen en verde (+)**
- Las transacciones de **gasto salen en rojo (-)**

---

## CARACTERÍSTICAS PRINCIPALES

✅ **Almacenamiento Local**: Todos tus datos se guardan EN TU TELÉFONO (no en un servidor)  
✅ **Funciona sin Internet**: Una vez cargada, puedes usarla sin conexión  
✅ **Seguridad**: Solo tú tienes acceso a tus datos  
✅ **Sincrónico**: Los cambios se guardan inmediatamente  
✅ **Diseño Móvil**: Optimizado para pantalla táctil  
✅ **Dark Mode**: Se adapta automáticamente a tu preferencia  

---

## TROUBLESHOOTING (Si algo no funciona)

### No veo el botón "Añadir a la pantalla de inicio"
- Asegúrate de estar en **Safari** (no Chrome u otro navegador)
- Recarga la página (tira hacia abajo)
- Intenta de nuevo

### La app se cierra cuando la cierro
- Esto es normal, pero se reabre al tocar el ícono
- Los datos siempre se guardan

### ¿Cómo borro los datos?
- En Safari: Ajustes → Safari → Historial → Borrar datos
- Esto borrará los datos guardados (ten cuidado)

### Quiero cambiar las categorías
- Avísame y modififico el código
- Puedo agregar nuevas categorías como "Ropa", "Educación", etc.

---

## PRÓXIMAS MEJORAS (Opcionales)

Si más adelante quieres que agregue:
- 📊 Gráficos visuales (pie charts, gráficas)
- 📅 Filtros por fecha/rango
- 🎯 Metas y presupuestos
- 💾 Exportar datos a Excel
- 🔔 Recordatorios
- 📱 Sincronización con la nube

Solo avísame y lo hacemos.

---

## PREGUNTAS FINALES

**¿Es seguro?**
Sí. Los datos están solo en tu teléfono. Nadie puede acceder a ellos.

**¿Puedo perder mis datos?**
Solo si borras el historial de Safari. Mientras no lo hagas, tus datos persisten.

**¿Funciona en iPad?**
Sí, el mismo proceso.

**¿Y en Android?**
Android tiene un proceso similar usando Chrome en lugar de Safari.

---

**¡Listo! Ya tienes tu app de finanzas funcional. Cualquier duda me avisas 💚**
